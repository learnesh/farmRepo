package com.logicgate.farm.domain;

public enum Color {
  RED,
  ORANGE,
  YELLOW,
  GREEN,
  BLUE,
  INDIGO,
  VIOLET,
  BRONZE,
  SILVER,
  GOLD,
  PLATINUM,
  WHITE,
  GRAY,
  BLACK,
  DARKER_THAN_BLACK
}
